# Deploying Crypto Bot to Google Cloud Platform (GCP)

This guide will help you deploy your trading bot to a **secure, always-on Google Cloud Virtual Machine (VM)**.

## Prerequisites
1.  A Google Cloud Account (Free Tier is sufficient).
2.  `gcloud` CLI installed on your local machine (or use the Cloud Console browser).
3.  Your Telegram Token and Chat ID ready.

---

## Step 1: Create a Virtual Machine (VM)
We will use a small, cost-effective Linux server.

1.  Go to **GCP Console > Compute Engine > VM Instances**.
2.  Click **Create Instance**.
3.  **Name:** `crypto-trading-bot`
4.  **Region:** Choose usually `us-central1` or close to you.
5.  **Machine Type:** `e2-micro` (often Free Tier eligible) or `e2-small` ($15/mo).
6.  **Boot Disk:** Change to **Ubuntu 22.04 LTS** (Standard Persistent Disk 30GB).
7.  **Firewall:** No HTTP/HTTPS needed (it's a backend bot).
8.  Click **Create**.

---

## Step 2: Prepare Your Code for Upload
1.  On your local machine, open terminal in `crypto-dashboard`.
2.  Make sure your `.env` file has your PROD keys:
    ```bash
    TELEGRAM_TOKEN=your_token
    TELEGRAM_CHAT_ID=your_id
    BINANCE_API_KEY=...
    BINANCE_SECRET=...
    ```
3.  Zip your project (excluding heavy virtual environments):
    ```bash
    zip -r crypto_bot.zip . -x "venv/*" -x ".git/*" -x "__pycache__/*"
    ```

---

## Step 3: Upload Code to VM
1.  In GCP Console, click the **SSH** button next to your specific VM. A terminal window opens.
2.  (Alternative) If you prefer local terminal:
    ```bash
    gcloud compute scp crypto_bot.zip rv@crypto-trading-bot:~
    ```
3.  In the VM SSH window, unzip:
    ```bash
    sudo apt-get update && sudo apt-get install -y unzip docker.io docker-compose
    unzip crypto_bot.zip -d bot
    cd bot
    ```

---

## Step 4: Run with Docker (Recommended)
This is the most reliable method. It builds a self-contained environment.

1.  **Build the Container:**
    ```bash
    sudo docker build -t crypto-bot .
    ```
    *(This takes ~2 minutes)*

2.  **Run in Background:**
    ```bash
    sudo docker run -d --restart unless-stopped --name trader \
      --env-file .env \
      -v $(pwd)/trading_engine/db.sqlite:/app/trading_engine/db.sqlite \
      crypto-bot
    ```
    *Flags explanation:*
    - `-d`: Detached mode (runs in background)
    - `--restart unless-stopped`: Auto-restarts if it crashes or VM reboots
    - `--env-file .env`: Injects your secrets
    - `-v ...`: Persists your database even if container is rebuilt

3.  **Check Logs:**
    ```bash
    sudo docker logs -f trader
    ```
    You should see: `Use 'Control-C' to exit logs (bot keeps running)`.

---

## Step 5: Monitoring & Commands

- **View Live Logs:** `sudo docker logs -t -f trader`
- **Stop Bot:** `sudo docker stop trader`
- **Restart Bot:** `sudo docker restart trader`
- **Update Code:**
  1. Upload new zip.
  2. Unzip over existing folder.
  3. `sudo docker build -t crypto-bot .`
  4. `sudo docker rm -f trader` (delete old container)
  5. Run the `docker run` command from Step 4 again.

---

## Step 6: Verify Telegram
You should receive a **"💓 SYSTEM PULSE"** message on Telegram immediately, and then every hour.

**✅ Deployment Complete!**
Your bot is now running 24/7 in the cloud.
